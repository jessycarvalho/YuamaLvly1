<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/main.css">
	<title>Cadastro</title>
  <style>
 .btn {
    background-color: #a8f0e7; 
    border: 2px solid #b493cc;
    color: #442D64;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
  }
  .btn:hover {
    background-color: transparent;
    color: #a8f0e7;
    border: 2px solid #a8f0e7
  }
</style>
  </head>
  <body>
	<br><br>
	<div class="container text-center">
		<a class="btn btn-primary" href="clientes.php" role="button" aria-label="Mute">
			<i class="bi bi-box-arrow-in-right"></i>
			Clientes
		</a>
	</div>
   

	
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>